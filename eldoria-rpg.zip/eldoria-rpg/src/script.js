// Função para exibir a aba selecionada e esconder as demais
function showTab(id) {
  document
    .querySelectorAll(".tab")
    .forEach((tab) => tab.classList.add("hidden"));
  document.getElementById(id).classList.remove("hidden");
}

// Função para gerar a ficha do personagem
function gerarFicha(event) {
  event.preventDefault(); // Impede o recarregamento da página

  const nome = document.getElementById("nome").value;
  const raca = document.getElementById("raca").value;
  const classe = document.getElementById("classe").value;
  const profissao = document.getElementById("profissao").value;

  const ficha = `Ficha de Personagem\n====================\nNome: ${nome}\nRaça: ${raca}\nClasse: ${classe}\nProfissão: ${profissao}`;
  document.getElementById("resultadoFicha").textContent = ficha;
}
